package factorysolution.com.br.faculdade;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ViewHolder viewHolder = new ViewHolder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Insere o layout na activity
        setContentView(R.layout.activity_main);

        // Busca os elementos da interface
        this.viewHolder.editReal = this.findViewById(R.id.edit_valor);
        this.viewHolder.textDollar =  this.findViewById(R.id.txt_dollar);
        this.viewHolder.CotDollar =  this.findViewById(R.id.vlr_dolar);
        this.viewHolder.textEuro =  this.findViewById(R.id.txt_euro);
        this.viewHolder.CotEuro =  this.findViewById(R.id.vlr_euro);
        this.viewHolder.buttonCalculate =  this.findViewById(R.id.btn_calcular);

        // Limpa os valores iniciais
        this.clearValues();

        // Adiciona evento de click no elemento
        this.viewHolder.buttonCalculate.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {

        // Verifica se o elemento clicado é o que nos interessa
        if (view.getId() == R.id.btn_calcular) {
            if (viewHolder.editReal.getText().toString().trim().equals("")) {
                viewHolder.editReal.setError("Campo Vazio");
            } else if(viewHolder.CotDollar.getText().toString().trim().equals("")) {
                viewHolder.CotDollar.setError("Campo Vazio");
            } else if(viewHolder.CotEuro.getText().toString().trim().equals("")) {
                viewHolder.CotEuro.setError("Campo Vazio");
            } else {
                // Obtém o valor do EditText
                Double mReal = Double.valueOf(this.viewHolder.editReal.getText().toString());
                Double vlrdolar = Double.valueOf(this.viewHolder.CotDollar.getText().toString());
                Double vlreuro = Double.valueOf(this.viewHolder.CotEuro.getText().toString());

                // Converte valores
                double resultdolar = mReal / vlrdolar;
                double resulteuro = mReal / vlreuro;
                this.viewHolder.textDollar.setText(String.format("%.2f", resultdolar));
                this.viewHolder.textEuro.setText(String.format("%.2f", resulteuro));
            }
        }
    }
    /**
     * Limpa os valores iniciais
     */
    private void clearValues() {
        this.viewHolder.textDollar.setText("");
        this.viewHolder.textEuro.setText("");
    }

    private static class ViewHolder {
        public EditText editReal;
        public TextView textDollar;
        public TextView textEuro;
        public Button buttonCalculate;
        public EditText CotDollar;
        public EditText CotEuro;

    }


}
